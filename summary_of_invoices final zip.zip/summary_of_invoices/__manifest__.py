{
    'name': 'Summary of Invoices',
    'version': '1.0',
    'summary': 'Generate Summary of Invoices Report',
    'description': 'Wizard to generate summary of selected invoices.',
    'author': 'Zanish Rohail',
    'website': '',
    'category': 'Accounting',
    'license': 'LGPL-3',

    'depends': [
        'account',
        'report_pdf_options',
    ],

    'data': [
    'security/ir.model.access.csv',
    'security/security.xml',
    'views/invoice_summary_wizard_view.xml',
    'views/summary_of_invoice_menu.xml',

        'report/report_action.xml',
        'report/report_template.xml',
    ],

    'installable': True,
    'application': True,
}