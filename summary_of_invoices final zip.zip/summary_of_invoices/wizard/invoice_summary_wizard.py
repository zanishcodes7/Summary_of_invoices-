from odoo import fields, models


class InvoiceSummaryWizard(models.TransientModel):
    _name = "invoice.summary.wizard"
    _description = "Invoice Summary Wizard"

    company_id = fields.Many2one(
        "res.company",
        string="Company",
        default=lambda self: self.env.company,
        readonly=True,
    )

    currency_id = fields.Many2one(
        "res.currency",
        related="company_id.currency_id",
        readonly=True,
    )

    invoice_ids = fields.Many2many(
        "account.move",
        string="Invoices",
        domain=[("move_type", "=", "out_invoice")],
    )

    date_generated = fields.Date(
        string="Date Generated",
        default=fields.Date.today,
    )

    def action_generate_report(self):
        return self.env.ref(
            "summary_of_invoices.action_invoice_summary_report"
        ).report_action(self)